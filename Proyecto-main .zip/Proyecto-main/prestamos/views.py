from django.shortcuts import render, redirect
from django.views.generic import ListView, CreateView, UpdateView, DeleteView, TemplateView, DetailView
from django.contrib.auth.mixins import LoginRequiredMixin
from django.db.models import Q
from django.urls import reverse_lazy
from nomina.mixins import TitleContextMixin
from .forms import PrestamoForm
from .models import  Prestamo
def home(request):
    data = {
        "title1": "Autor | nose xd",
        "title2": "Gestión de Nóminas"
    }
    return render(request, 'home.html', data)


class HomeTemplateView(TitleContextMixin, TemplateView):
    template_name = 'home.html'

class PrestamoListView(LoginRequiredMixin, TitleContextMixin, ListView):
    model = Prestamo
    template_name = 'prestamo/list.html'
    context_object_name = 'prestamo'
    paginate_by = 10
    title1 = "Autor | nose xd"
    title2 = "Listado de prestamos"

    def get_queryset(self):
        queryset = super().get_queryset()
        query = self.request.GET.get('q', '')
        if query:
            queryset = queryset.filter(Q(empleado__nombre__icontains=query) | Q(empleado__cedula__icontains=query))
        return queryset


class PrestamoCreateView(LoginRequiredMixin, TitleContextMixin, CreateView):
    model = Prestamo
    form_class = PrestamoForm
    template_name = "prestamo/form.html"
    success_url = reverse_lazy("prestamos:prestamo_list")
    title1 = "prestamo"
    title2 = "Crear Nuevo prestamo"

    def form_valid(self, form):
        form.instance.usuario = self.request.user  # ✅ Solución principal
        return super().form_valid(form)


class PrestamoUpdateView(LoginRequiredMixin, TitleContextMixin, UpdateView):
    model = Prestamo
    form_class = PrestamoForm
    template_name = "prestamo/form.html"
    success_url = reverse_lazy("prestamos:prestamo_list")
    title1 = "prestamo"
    title2 = "Editar prestamo"


class PrestamoDeleteView(LoginRequiredMixin, TitleContextMixin, DeleteView):
    model = Prestamo
    template_name = "prestamo/delete.html"
    success_url = reverse_lazy("prestamos:prestamo_list")
    title1 = "Eliminar"
    title2 = "Eliminar prestamo"

class PrestamoDetailView(LoginRequiredMixin, TitleContextMixin, DetailView):
    model = Prestamo
    template_name = "prestamo/detail.html"
    context_object_name = "prestamo"  # nombre del objeto en el template
    title1 = "Prestamo"
    title2 = "Datos del Prestamo"
    success_url = reverse_lazy("prestamo:prestamo_list")
