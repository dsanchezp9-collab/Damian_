from django import forms
from .models import Prestamo

class PrestamoForm(forms.ModelForm):
    class Meta:
        model = Prestamo
        fields = ['image','empleado', 'tipo_prestamo', 'fecha_prestamo', 'monto', 'numero_cuotas']