from django.db import models
from  nomina.models import Empleado


class TipoPrestamo(models.Model):
    descripcion = models.CharField(max_length=100)
    tasa = models.IntegerField(default=0)
    
    def __str__(self):
        return self.descripcion
class Prestamo(models.Model):
    image = models.ImageField(verbose_name='Foto',upload_to='customers/',blank=True,null=True,default='customers/default.png')
    empleado = models.ForeignKey(Empleado, on_delete=models.CASCADE)
    tipo_prestamo = models.ForeignKey(TipoPrestamo, on_delete=models.CASCADE)
    fecha_prestamo = models.DateField()
    monto = models.DecimalField(max_digits=10, decimal_places=2)
    interes = models.DecimalField(max_digits=10, decimal_places=2, editable=False)
    monto_pagar = models.DecimalField(max_digits=10, decimal_places=2, editable=False)
    numero_cuotas = models.PositiveIntegerField(default=1)
    cuota_mensual = models.DecimalField(max_digits=10, decimal_places=2, editable=False)
    saldo = models.DecimalField(max_digits=10, decimal_places=2, editable=False)

    def save(self, *args, **kwargs):
        # Calcular los valores automáticos antes de guardar
        if self.tipo_prestamo and self.monto and self.numero_cuotas:
            self.interes = self.monto * self.tipo_prestamo.tasa / 100
            self.monto_pagar = self.monto + self.interes
            self.cuota_mensual = self.monto_pagar / self.numero_cuotas
            self.saldo = self.monto_pagar
        super().save(*args, **kwargs)

    def __str__(self):
        return f"Préstamo de {self.empleado.nombre} - {self.tipo_prestamo.descripcion}"