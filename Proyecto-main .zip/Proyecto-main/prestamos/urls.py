from django.urls import path
from prestamos import views
app_name='prestamos'
urlpatterns = [
   #path('', views.home,name='home'),
   path('', views.HomeTemplateView.as_view(),name='home'),
   path('prestamo_list/', views.PrestamoListView.as_view(),name='prestamo_list'),
   path('prestamo_create/', views.PrestamoCreateView.as_view(),name='prestamo_create'),
   path('prestamo_update/<int:pk>/', views.PrestamoUpdateView.as_view(),name='prestamo_update'),
   path('prestamo_delete/<int:pk>/', views.PrestamoDeleteView.as_view(),name='prestamo_delete'),
   path('prestamo_detail/<int:pk>/', views.PrestamoDetailView.as_view(),name='prestamo_detail'),
]