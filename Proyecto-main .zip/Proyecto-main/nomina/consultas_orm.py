# ===================================================
# EJERCICIOS ORM - Sistema de Nómina
# Ejecutar con: python manage.py shell < consultas_orm.py
# O copiar y pegar en: python manage.py shell
# ===================================================

from datetime import date
from django.db.models import Sum, Avg, Count, Max, Min, F
from nomina.models import Empleado, Nomina, NominaDetalle
from prestamos.models import Prestamo, TipoPrestamo
from sobretiempo.models import Sobretiempo, TipoSobretiempo

print("\n" + "="*60)
print("INICIANDO EJERCICIOS ORM")
print("="*60 + "\n")

# ===================================================
# MODELO: EMPLEADO
# ===================================================
print("=== EMPLEADO ===\n")

# --- CREAR 5 EMPLEADOS ---
print("1) CREAR 5 empleados:")
e1 = Empleado.objects.create(cedula="1001", nombre="Juan Pérez", sueldo=1200.00)
e2 = Empleado.objects.create(cedula="1002", nombre="María García", sueldo=1500.00)
e3 = Empleado.objects.create(cedula="1003", nombre="Carlos López", sueldo=1800.00)
e4 = Empleado(cedula="1004", nombre="Ana Martínez", sueldo=2000.00)
e4.save()
e5 = Empleado(cedula="1005", nombre="Luis Rodríguez", sueldo=2500.00)
e5.save()
print(f"✅ Empleados creados: {Empleado.objects.count()}\n")

# --- ACTUALIZAR 5 EMPLEADOS ---
print("2) ACTUALIZAR 5 empleados:")
# Update 1: usando update()
Empleado.objects.filter(cedula="1001").update(sueldo=1300.00)
# Update 2: usando save()
emp = Empleado.objects.get(cedula="1002")
emp.nombre = "María G. García"
emp.save()
# Update 3: usando F()
Empleado.objects.filter(cedula="1003").update(sueldo=F('sueldo') + 200)
# Update 4: save() en otro
emp2 = Empleado.objects.get(cedula="1004")
emp2.sueldo = 2100.00
emp2.save()
# Update 5: update múltiple
Empleado.objects.filter(sueldo__gte=2000).update(sueldo=F('sueldo') + 100)
print("✅ Empleados actualizados\n")

# --- LISTAR 10 CONSULTAS ---
print("3) LISTAR 10 consultas:")
print("a) all():", Empleado.objects.all())
print("b) filter sueldo > 1500:", list(Empleado.objects.filter(sueldo__gt=1500).values('nombre', 'sueldo')))
print("c) filter sueldo < 2000:", list(Empleado.objects.filter(sueldo__lt=2000).values('nombre', 'sueldo')))
print("d) nombre__icontains 'ar':", list(Empleado.objects.filter(nombre__icontains='ar').values('nombre')))
print("e) nombre__startswith 'M':", list(Empleado.objects.filter(nombre__startswith='M').values('nombre')))
print("f) nombre__endswith 'z':", list(Empleado.objects.filter(nombre__endswith='z').values('nombre')))
print("g) sueldo__range (1200, 2000):", list(Empleado.objects.filter(sueldo__range=(1200, 2000)).values('nombre', 'sueldo')))
print("h) exclude sueldo > 2500:", list(Empleado.objects.exclude(sueldo__gt=2500).values('nombre', 'sueldo')))
print("i) get cedula=1001:", Empleado.objects.get(cedula="1001"))
print("j) count():", Empleado.objects.count())
print()

# --- ELIMINAR 2 EMPLEADOS ---
print("4) ELIMINAR 2 empleados:")
Empleado.objects.filter(cedula="1004").delete()
Empleado.objects.filter(cedula="1005").delete()
print(f"✅ Empleados restantes: {Empleado.objects.count()}\n")

# ===================================================
# MODELO: PRESTAMO
# ===================================================
print("=== PRESTAMO ===\n")

# Crear tipo de préstamo si no existe
tipo_personal, _ = TipoPrestamo.objects.get_or_create(
    descripcion="Personal",
    defaults={'tasa': 5}
)

# --- CREAR 5 PRESTAMOS ---
print("1) CREAR 5 préstamos:")
emp_base = Empleado.objects.first()
p1 = Prestamo.objects.create(empleado=emp_base, tipo_prestamo=tipo_personal, 
                              fecha_prestamo=date(2024, 1, 15), monto=500.00, numero_cuotas=5)
p2 = Prestamo.objects.create(empleado=emp_base, tipo_prestamo=tipo_personal,
                              fecha_prestamo=date(2024, 3, 20), monto=800.00, numero_cuotas=8)
p3 = Prestamo.objects.create(empleado=emp_base, tipo_prestamo=tipo_personal,
                              fecha_prestamo=date(2024, 6, 10), monto=1000.00, numero_cuotas=10)
p4 = Prestamo(empleado=emp_base, tipo_prestamo=tipo_personal,
              fecha_prestamo=date(2025, 1, 5), monto=300.00, numero_cuotas=3)
p4.save()
p5 = Prestamo(empleado=emp_base, tipo_prestamo=tipo_personal,
              fecha_prestamo=date(2025, 2, 10), monto=1500.00, numero_cuotas=12)
p5.save()
print(f"✅ Préstamos creados: {Prestamo.objects.count()}\n")

# --- ACTUALIZAR 5 PRESTAMOS ---
print("2) ACTUALIZAR 5 préstamos:")
Prestamo.objects.filter(monto__lt=600).update(monto=F('monto') + 100)
pres = Prestamo.objects.filter(fecha_prestamo__year=2024).first()
if pres:
    pres.numero_cuotas = 6
    pres.save()
Prestamo.objects.filter(monto__gte=1000).update(numero_cuotas=15)
pres2 = Prestamo.objects.filter(monto=800).first()
if pres2:
    pres2.fecha_prestamo = date(2024, 4, 1)
    pres2.save()
Prestamo.objects.all().update(saldo=F('monto_pagar'))
print("✅ Préstamos actualizados\n")

# --- LISTAR 10 CONSULTAS ---
print("3) LISTAR 10 consultas:")
print("a) all():", Prestamo.objects.all())
print("b) monto__gte 500:", list(Prestamo.objects.filter(monto__gte=500).values('monto', 'fecha_prestamo')))
print("c) monto__lte 1000:", list(Prestamo.objects.filter(monto__lte=1000).values('monto')))
print("d) fecha_prestamo__year 2024:", list(Prestamo.objects.filter(fecha_prestamo__year=2024).values('monto', 'fecha_prestamo')))
print("e) monto__range (300, 900):", list(Prestamo.objects.filter(monto__range=(300, 900)).values('monto')))
print("f) monto__exact 1500:", list(Prestamo.objects.filter(monto__exact=1500).values('monto')))
print("g) empleado__nombre__icontains 'Juan':", list(Prestamo.objects.filter(empleado__nombre__icontains='Juan').values('monto')))
print("h) exclude monto > 1200:", list(Prestamo.objects.exclude(monto__gt=1200).values('monto')))
print("i) tipo_prestamo__descripcion Personal:", list(Prestamo.objects.filter(tipo_prestamo__descripcion='Personal').values('monto')))
print("j) count():", Prestamo.objects.count())
print()

# --- ELIMINAR 2 PRESTAMOS ---
print("4) ELIMINAR 2 préstamos:")
Prestamo.objects.filter(monto__lt=400).delete()
Prestamo.objects.filter(monto__gt=1400).delete()
print(f"✅ Préstamos restantes: {Prestamo.objects.count()}\n")

# ===================================================
# MODELO: SOBRETIEMPO
# ===================================================
print("=== SOBRETIEMPO ===\n")

# Crear tipo sobretiempo si no existe
tipo_50, _ = TipoSobretiempo.objects.get_or_create(
    codigo="H50",
    defaults={'descripcion': "Horas al 50%", 'factor': 1.50}
)

# --- CREAR 5 SOBRETIEMPOS ---
print("1) CREAR 5 sobretiempos:")
emp_base = Empleado.objects.first()
s1 = Sobretiempo.objects.create(empleado=emp_base, fecha_registro=date(2024, 11, 1),
                                 tipo_sobretiempo=tipo_50, numero_horas=2, valor=15.00)
s2 = Sobretiempo.objects.create(empleado=emp_base, fecha_registro=date(2024, 11, 5),
                                 tipo_sobretiempo=tipo_50, numero_horas=3, valor=22.50)
s3 = Sobretiempo.objects.create(empleado=emp_base, fecha_registro=date(2024, 10, 20),
                                 tipo_sobretiempo=tipo_50, numero_horas=4, valor=30.00)
s4 = Sobretiempo(empleado=emp_base, fecha_registro=date(2024, 9, 15),
                 tipo_sobretiempo=tipo_50, numero_horas=1, valor=7.50)
s4.save()
s5 = Sobretiempo(empleado=emp_base, fecha_registro=date(2024, 8, 10),
                 tipo_sobretiempo=tipo_50, numero_horas=5, valor=37.50)
s5.save()
print(f"✅ Sobretiempos creados: {Sobretiempo.objects.count()}\n")

# --- ACTUALIZAR 5 SOBRETIEMPOS ---
print("2) ACTUALIZAR 5 sobretiempos:")
Sobretiempo.objects.filter(numero_horas__lt=2).update(numero_horas=2)
sobre = Sobretiempo.objects.filter(fecha_registro__month=11).first()
if sobre:
    sobre.numero_horas = 4
    sobre.save()
Sobretiempo.objects.filter(valor__lt=20).update(valor=F('valor') + 5)
sobre2 = Sobretiempo.objects.filter(numero_horas__gte=4).first()
if sobre2:
    sobre2.valor = 40.00
    sobre2.save()
Sobretiempo.objects.all().update(valor=F('valor') + 2)
print("✅ Sobretiempos actualizados\n")

# --- LISTAR 10 CONSULTAS ---
print("3) LISTAR 10 consultas:")
print("a) all():", Sobretiempo.objects.all())
print("b) numero_horas__gte 3:", list(Sobretiempo.objects.filter(numero_horas__gte=3).values('numero_horas', 'valor')))
print("c) fecha_registro__year 2024:", list(Sobretiempo.objects.filter(fecha_registro__year=2024).values('fecha_registro')))
print("d) fecha_registro__month 11:", list(Sobretiempo.objects.filter(fecha_registro__month=11).values('fecha_registro')))
print("e) valor__range (10, 30):", list(Sobretiempo.objects.filter(valor__range=(10, 30)).values('valor')))
print("f) empleado__nombre__icontains 'Juan':", list(Sobretiempo.objects.filter(empleado__nombre__icontains='Juan').values('numero_horas')))
print("g) tipo_sobretiempo__codigo H50:", list(Sobretiempo.objects.filter(tipo_sobretiempo__codigo='H50').values('numero_horas')))
print("h) exclude numero_horas > 4:", list(Sobretiempo.objects.exclude(numero_horas__gt=4).values('numero_horas')))
print("i) fecha_registro__gte 2024-10-01:", list(Sobretiempo.objects.filter(fecha_registro__gte=date(2024,10,1)).values('fecha_registro')))
print("j) count():", Sobretiempo.objects.count())
print()

# --- ELIMINAR 2 SOBRETIEMPOS ---
print("4) ELIMINAR 2 sobretiempos:")
Sobretiempo.objects.filter(numero_horas=1).delete()
Sobretiempo.objects.filter(fecha_registro__year=2024, fecha_registro__month=8).delete()
print(f"✅ Sobretiempos restantes: {Sobretiempo.objects.count()}\n")

# ===================================================
# MODELO: NOMINA
# ===================================================
print("=== NOMINA ===\n")

# --- CREAR 5 NOMINAS ---
print("1) CREAR 5 nóminas:")
n1 = Nomina.objects.create(aniomes="202401", fecha_generacion=date(2024, 1, 31))
n2 = Nomina.objects.create(aniomes="202402", fecha_generacion=date(2024, 2, 29))
n3 = Nomina.objects.create(aniomes="202410", fecha_generacion=date(2024, 10, 31))
n4 = Nomina(aniomes="202411", fecha_generacion=date(2024, 11, 30))
n4.save()
n5 = Nomina(aniomes="202501", fecha_generacion=date(2025, 1, 31))
n5.save()
print(f"✅ Nóminas creadas: {Nomina.objects.count()}\n")

# --- ACTUALIZAR 5 NOMINAS ---
print("2) ACTUALIZAR 5 nóminas:")
Nomina.objects.filter(aniomes="202401").update(fecha_generacion=date(2024, 1, 30))
nom = Nomina.objects.get(aniomes="202402")
nom.fecha_generacion = date(2024, 2, 28)
nom.save()
Nomina.objects.filter(aniomes__startswith="2024").update(aniomes=F('aniomes'))
nom2 = Nomina.objects.filter(aniomes="202410").first()
if nom2:
    nom2.aniomes = "202410"
    nom2.save()
Nomina.objects.filter(fecha_generacion__year=2024).update(fecha_generacion=date(2024, 12, 31))
print("✅ Nóminas actualizadas\n")

# --- LISTAR 10 CONSULTAS ---
print("3) LISTAR 10 consultas:")
print("a) all():", Nomina.objects.all())
print("b) aniomes__startswith '2024':", list(Nomina.objects.filter(aniomes__startswith='2024').values('aniomes')))
print("c) fecha_generacion__year 2024:", list(Nomina.objects.filter(fecha_generacion__year=2024).values('aniomes', 'fecha_generacion')))
print("d) fecha_generacion__month 1:", list(Nomina.objects.filter(fecha_generacion__month=1).values('aniomes')))
print("e) aniomes__gte '202410':", list(Nomina.objects.filter(aniomes__gte='202410').values('aniomes')))
print("f) aniomes__lte '202402':", list(Nomina.objects.filter(aniomes__lte='202402').values('aniomes')))
print("g) fecha_generacion__range:", list(Nomina.objects.filter(fecha_generacion__range=(date(2024,1,1), date(2024,12,31))).values('aniomes')))
print("h) exclude aniomes__startswith '2025':", list(Nomina.objects.exclude(aniomes__startswith='2025').values('aniomes')))
print("i) aniomes__contains '01':", list(Nomina.objects.filter(aniomes__contains='01').values('aniomes')))
print("j) count():", Nomina.objects.count())
print()

# --- ELIMINAR 2 NOMINAS ---
print("4) ELIMINAR 2 nóminas:")
Nomina.objects.filter(aniomes="202401").delete()
Nomina.objects.filter(aniomes="202501").delete()
print(f"✅ Nóminas restantes: {Nomina.objects.count()}\n")

# ===================================================
# MODELO: NOMINA DETALLE
# ===================================================
print("=== NOMINA DETALLE ===\n")

# --- CREAR 5 DETALLES ---
print("1) CREAR 5 detalles de nómina:")
nomina_base = Nomina.objects.first()
emp1 = Empleado.objects.first()
nd1 = NominaDetalle.objects.create(nomina=nomina_base, empleado=emp1, 
                                    sueldo=1300.00, total_ingresos=1300.00, 
                                    total_egresos=200.00, neto=1100.00)
nd2 = NominaDetalle.objects.create(nomina=nomina_base, empleado=emp1,
                                    sueldo=1500.00, total_ingresos=1500.00,
                                    total_egresos=250.00, neto=1250.00)
nd3 = NominaDetalle.objects.create(nomina=nomina_base, empleado=emp1,
                                    sueldo=2000.00, total_ingresos=2000.00,
                                    total_egresos=300.00, neto=1700.00)
nd4 = NominaDetalle(nomina=nomina_base, empleado=emp1,
                    sueldo=1800.00, total_ingresos=1800.00,
                    total_egresos=280.00, neto=1520.00)
nd4.save()
nd5 = NominaDetalle(nomina=nomina_base, empleado=emp1,
                    sueldo=2200.00, total_ingresos=2200.00,
                    total_egresos=350.00, neto=1850.00)
nd5.save()
print(f"✅ Detalles creados: {NominaDetalle.objects.count()}\n")

# --- ACTUALIZAR 5 DETALLES ---
print("2) ACTUALIZAR 5 detalles:")
NominaDetalle.objects.filter(sueldo__lt=1500).update(sueldo=F('sueldo') + 100)
det = NominaDetalle.objects.filter(neto__lt=1300).first()
if det:
    det.neto = 1300.00
    det.save()
NominaDetalle.objects.filter(total_egresos__lt=280).update(total_egresos=F('total_egresos') + 50)
det2 = NominaDetalle.objects.filter(sueldo__gte=2000).first()
if det2:
    det2.total_ingresos = 2500.00
    det2.save()
NominaDetalle.objects.all().update(neto=F('total_ingresos') - F('total_egresos'))
print("✅ Detalles actualizados\n")

# --- LISTAR 10 CONSULTAS ---
print("3) LISTAR 10 consultas:")
print("a) all():", NominaDetalle.objects.all())
print("b) sueldo__gte 1500:", list(NominaDetalle.objects.filter(sueldo__gte=1500).values('sueldo', 'neto')))
print("c) neto__lt 1500:", list(NominaDetalle.objects.filter(neto__lt=1500).values('neto')))
print("d) empleado__nombre__icontains 'Juan':", list(NominaDetalle.objects.filter(empleado__nombre__icontains='Juan').values('sueldo')))
print("e) nomina__aniomes '202402':", list(NominaDetalle.objects.filter(nomina__aniomes='202402').values('sueldo', 'neto')))
print("f) total_egresos__range (200, 300):", list(NominaDetalle.objects.filter(total_egresos__range=(200, 300)).values('total_egresos')))
print("g) total_ingresos__gte 2000:", list(NominaDetalle.objects.filter(total_ingresos__gte=2000).values('total_ingresos')))
print("h) exclude neto > 1800:", list(NominaDetalle.objects.exclude(neto__gt=1800).values('neto')))
print("i) nomina__fecha_generacion__year 2024:", list(NominaDetalle.objects.filter(nomina__fecha_generacion__year=2024).values('sueldo')))
print("j) count():", NominaDetalle.objects.count())
print()

# --- ELIMINAR 2 DETALLES ---
print("4) ELIMINAR 2 detalles:")
NominaDetalle.objects.filter(sueldo__lt=1400).delete()
NominaDetalle.objects.filter(neto__gt=1800).delete()
print(f"✅ Detalles restantes: {NominaDetalle.objects.count()}\n")

# ===================================================
# CONSULTAS AGREGADAS Y ANOTADAS (10)
# ===================================================
print("\n" + "="*60)
print("CONSULTAS AGREGADAS Y ANOTADAS")
print("="*60 + "\n")

print("1) Total de préstamos por empleado:")
print(Prestamo.objects.values('empleado__nombre').annotate(total=Sum('monto')).order_by('-total'))

print("\n2) Promedio de sueldos de empleados:")
print(Empleado.objects.aggregate(promedio=Avg('sueldo')))

print("\n3) Total de horas extra por empleado:")
print(Sobretiempo.objects.values('empleado__nombre').annotate(total_horas=Sum('numero_horas')).order_by('-total_horas'))

print("\n4) Total a pagar por nómina:")
print(NominaDetalle.objects.values('nomina__aniomes').annotate(total=Sum('neto')).order_by('nomina__aniomes'))

print("\n5) Número de empleados por año de registro:")
print(Empleado.objects.annotate(anio=F('fecha_ingreso__year')).values('anio').annotate(cantidad=Count('id')).order_by('anio'))

print("\n6) Sueldo máximo y mínimo:")
print(Empleado.objects.aggregate(max_sueldo=Max('sueldo'), min_sueldo=Min('sueldo')))

print("\n7) Cantidad total de préstamos y suma de montos:")
print(Prestamo.objects.aggregate(cantidad=Count('id'), total=Sum('monto')))

print("\n8) Promedio de valor de sobretiempos:")
print(Sobretiempo.objects.aggregate(promedio_valor=Avg('valor')))

print("\n9) Empleados con más de 3 horas extra:")
print(Sobretiempo.objects.values('empleado__nombre').annotate(total_horas=Sum('numero_horas')).filter(total_horas__gt=3))

print("\n10) Top 5 empleados con mayor neto en nómina:")
print(NominaDetalle.objects.select_related('empleado').values('empleado__nombre').annotate(total_neto=Sum('neto')).order_by('-total_neto')[:5])

print("\n" + "="*60)
print("EJERCICIOS COMPLETADOS EXITOSAMENTE")
print("="*60)