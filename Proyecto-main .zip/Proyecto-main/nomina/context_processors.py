from django.db.models import Sum
from .models import Empleado, Nomina, NominaDetalle

def datos_base(request):
    total_empleados = Empleado.objects.count()

    ultima_nomina = Nomina.objects.order_by('-aniomes').first()

    total_neto_pagado = 0
    if ultima_nomina:
        total_neto_pagado = NominaDetalle.objects.filter(nomina=ultima_nomina).aggregate(
            total=Sum('neto')
        )['total'] or 0

    return {
        'total_empleados': total_empleados,
        'ultima_nomina': ultima_nomina,
        'total_neto_pagado': total_neto_pagado,
    }
