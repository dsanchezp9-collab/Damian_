from django.urls import path
from nomina import views
app_name='nomina'
urlpatterns = [
   #path('', views.home,name='home'),
   path('', views.HomeTemplateView.as_view(),name='home'),
   path('empleado_list/', views.EmpleadoListView.as_view(),name='empleado_list'),
   path('empleado_create/', views.EmpleadoCreateView.as_view(),name='empleado_create'),
   path('empleado_update/<int:pk>/', views.EmpleadoUpdateView.as_view(),name='empleado_update'),
   path('empleado_delete/<int:pk>/', views.EmpleadoDeleteView.as_view(),name='empleado_delete'),
   path('empleado_detail/<int:pk>/', views.EmpleadoDetailView.as_view(),name='empleado_detail'),
   path('nomina_list/', views.NominaListView.as_view(),name='nomina_list'),
   path('nomina_create/', views.NominaCreateView.as_view(),name='nomina_create'),
   path('nomina_update/<int:pk>/', views.NominaUpdateView.as_view(),name='nomina_update'),
   path('nomina_delete/<int:pk>/', views.NominaDeleteView.as_view(),name='nomina_delete'),
   path('nominadetalle_list/', views.NominaDetalleListView.as_view(),name='nominadetalle_list'),
   path('nominadetalle_create/', views.NominaDetalleCreateView.as_view(),name='nominadetalle_create'),
   path('nominadetalle_update/<int:pk>/', views.NominaDetalleUpdateView.as_view(),name='nominadetalle_update'),
   path('nominadetalle_delete/<int:pk>/', views.NominaDetalleDeleteView.as_view(),name='nominadetalle_delete'),
   path('nominadetalle_detail/<int:pk>/', views.NominaDetalleDetailView.as_view(),name='nominadetalle_detail'),
]