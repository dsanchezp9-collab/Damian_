from django.contrib import admin
from nomina.models import Empleado,Nomina,NominaDetalle
from prestamos.models import TipoPrestamo, Prestamo
from sobretiempo.models import TipoSobretiempo, Sobretiempo
admin.site.register(Empleado)
admin.site.register(Nomina)
admin.site.register(NominaDetalle)
admin.site.register(TipoPrestamo)
admin.site.register(Prestamo)
admin.site.register(TipoSobretiempo)
admin.site.register(Sobretiempo)