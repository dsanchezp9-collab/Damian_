from django import forms
from nomina.models import Empleado
from nomina.models import Nomina, NominaDetalle

class EmpleadoForm(forms.ModelForm):
    class Meta:
        model = Empleado
        fields = ['cedula', 'nombre', 'sueldo','image', 'departamento', 'cargo']

class NominaForm(forms.ModelForm):
    class Meta:
        model = Nomina
        fields = ['aniomes']

class NominaDetalleForm(forms.ModelForm):
    class Meta:
        model = NominaDetalle
        fields = ['nomina', 'empleado', 'sueldo', 'bono', 'prestamo']
    def clean_empleado(self):
        empleado = self.cleaned_data.get("empleado")
        nomina = self.cleaned_data.get("nomina")

        if nomina and empleado:
            # Verificamos si ese empleado ya está registrado en esa nómina
            if NominaDetalle.objects.filter(nomina=nomina, empleado=empleado).exclude(pk=self.instance.pk).exists():
                raise forms.ValidationError("❌ Este empleado ya está registrado en esta nómina.")
        return empleado