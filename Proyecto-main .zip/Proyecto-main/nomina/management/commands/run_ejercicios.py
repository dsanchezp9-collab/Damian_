# nomina/management/commands/run_ejercicios.py
from datetime import date
from decimal import Decimal
from django.core.management.base import BaseCommand
from django.db.models import Sum, Avg, Count, Max, Min, F
from django.contrib.auth import get_user_model

# imports seguros (si alguna app no existe, la sección se omite)
try:
    from nomina.models import Empleado, Nomina, NominaDetalle
except Exception:
    raise ImportError("La app 'nomina' debe existir y contener Empleado, Nomina, NominaDetalle")

try:
    from prestamos.models import Prestamo, TipoPrestamo
except Exception:
    Prestamo = None
    TipoPrestamo = None

try:
    from sobretiempo.models import Sobretiempo, TipoSobretiempo
except Exception:
    Sobretiempo = None
    TipoSobretiempo = None

User = get_user_model()


class Command(BaseCommand):
    help = "Ejercicios ORM: crear/actualizar/listar/eliminar y consultas agregadas"

    def handle(self, *args, **options):
        self.stdout.write("\n=== INICIANDO EJERCICIOS ORM ===\n")

        usuario, creado = User.objects.get_or_create(
            username="admin",
            defaults={'is_staff': True, 'is_superuser': True}
        )
        if creado:
            usuario.set_password("admin123")
            usuario.save()
            self.stdout.write("Usuario 'admin' creado (password: admin123)\n")

        # -----------------------
        # EMPLEADO
        # -----------------------
        self.stdout.write("=== EMPLEADO ===")
        Empleado.objects.filter(cedula__in=["1001","1002","1003","1004","1005"]).delete()
        self.stdout.write("Limpieza: OK")

        # crear (usar Decimal para sueldos)
        e1 = Empleado.objects.create(cedula="1001", nombre="Juan Pérez", sueldo=Decimal('1200.00'), usuario=usuario)
        e2 = Empleado.objects.create(cedula="1002", nombre="María García", sueldo=Decimal('1500.00'), usuario=usuario)
        e3 = Empleado.objects.create(cedula="1003", nombre="Carlos López", sueldo=Decimal('1800.00'), usuario=usuario)
        e4 = Empleado(cedula="1004", nombre="Ana Martínez", sueldo=Decimal('2000.00'), usuario=usuario); e4.save()
        e5 = Empleado(cedula="1005", nombre="Luis Rodríguez", sueldo=Decimal('2500.00'), usuario=usuario); e5.save()
        self.stdout.write("Creación: 5 empleados creados")

        # actualizar 5
        Empleado.objects.filter(cedula="1001").update(sueldo=Decimal('1300.00'))
        emp = Empleado.objects.get(cedula="1002"); emp.nombre = "María G. García"; emp.save()
        Empleado.objects.filter(cedula="1003").update(sueldo=F('sueldo') + Decimal('200.00'))
        emp2 = Empleado.objects.get(cedula="1004"); emp2.sueldo = Decimal('2100.00'); emp2.save()
        Empleado.objects.filter(sueldo__gte=Decimal('2000.00')).update(sueldo=F('sueldo') + Decimal('100.00'))
        self.stdout.write("Actualización: OK")

        # listados (incluye ejemplo __year con usuario.date_joined si aplica)
        self.stdout.write(f"all(): {Empleado.objects.filter(cedula__in=['1001','1002','1003','1004','1005'])}")
        self.stdout.write(f"sueldo > 1500: {list(Empleado.objects.filter(sueldo__gt=Decimal('1500.00')).values('nombre','sueldo'))}")
        self.stdout.write(f"sueldo < 2000: {list(Empleado.objects.filter(sueldo__lt=Decimal('2000.00')).values('nombre','sueldo'))}")
        self.stdout.write(f"nombre__icontains 'ar': {list(Empleado.objects.filter(nombre__icontains='ar').values('nombre'))}")
        self.stdout.write(f"nombre__startswith 'M': {list(Empleado.objects.filter(nombre__startswith='M').values('nombre'))}")
        self.stdout.write(f"nombre__endswith 'z': {list(Empleado.objects.filter(nombre__endswith='z').values('nombre'))}")
        self.stdout.write(f"sueldo__range (1200,2000): {list(Empleado.objects.filter(sueldo__range=(Decimal('1200.00'), Decimal('2000.00'))).values('nombre','sueldo'))}")
        self.stdout.write(f"exclude sueldo>2500: {list(Empleado.objects.exclude(sueldo__gt=Decimal('2500.00')).values('nombre','sueldo'))}")
        # ejemplo __year (si tu modelo tiene fecha de ingreso o usas usuario.date_joined)
        try:
            self.stdout.write(f"empleados registrados en 2024: {list(Empleado.objects.filter(usuario__date_joined__year=2024).values('cedula','nombre'))}")
        except Exception:
            self.stdout.write("empleados por año: campo usuario__date_joined no aplicable")
        self.stdout.write(f"count: {Empleado.objects.filter(cedula__in=['1001','1002','1003','1004','1005']).count()}")

        # eliminar 2
        Empleado.objects.filter(cedula="1004").delete()
        Empleado.objects.filter(cedula="1005").delete()
        self.stdout.write("Eliminación: 2 empleados eliminados\n")

        # -----------------------
        # PRESTAMO
        # -----------------------
        if Prestamo is None:
            self.stdout.write("Se omite PRESTAMO: app no encontrada\n")
        else:
            self.stdout.write("=== PRESTAMO ===")
            Prestamo.objects.filter(fecha_prestamo__year__gte=2024, empleado__cedula__in=['1001']).delete()
            tipo_personal, _ = TipoPrestamo.objects.get_or_create(descripcion="Personal", defaults={'tasa': 5})
            emp_base = Empleado.objects.get(cedula="1001")
            p1 = Prestamo.objects.create(empleado=emp_base, tipo_prestamo=tipo_personal, fecha_prestamo=date(2024,1,15), monto=Decimal('500.00'), numero_cuotas=5)
            p2 = Prestamo.objects.create(empleado=emp_base, tipo_prestamo=tipo_personal, fecha_prestamo=date(2024,3,20), monto=Decimal('800.00'), numero_cuotas=8)
            p3 = Prestamo.objects.create(empleado=emp_base, tipo_prestamo=tipo_personal, fecha_prestamo=date(2024,6,10), monto=Decimal('1000.00'), numero_cuotas=10)
            p4 = Prestamo(empleado=emp_base, tipo_prestamo=tipo_personal, fecha_prestamo=date(2025,1,5), monto=Decimal('300.00'), numero_cuotas=3); p4.save()
            p5 = Prestamo(empleado=emp_base, tipo_prestamo=tipo_personal, fecha_prestamo=date(2025,2,10), monto=Decimal('1500.00'), numero_cuotas=12); p5.save()
            self.stdout.write("Creación: 5 préstamos")

            # actualizaciones (incluye marcar pagado si existe ese campo)
            Prestamo.objects.filter(id=p1.id).update(monto=F('monto') + Decimal('100.00'))
            p2.numero_cuotas = 10; p2.save()
            Prestamo.objects.filter(id=p3.id).update(numero_cuotas=15)
            p4.monto = Decimal('400.00'); p4.save()
            try:
                Prestamo.objects.filter(id__in=[p1.id, p2.id]).update(pagado=True)
            except Exception:
                pass
            self.stdout.write("Actualización: OK")

            # listados
            prestamos = [p1.id, p2.id, p3.id, p4.id, p5.id]
            self.stdout.write(f"all(): {Prestamo.objects.filter(id__in=prestamos)}")
            self.stdout.write(f"monto__gte 500: {list(Prestamo.objects.filter(monto__gte=Decimal('500.00')).values('monto','fecha_prestamo'))}")
            self.stdout.write(f"monto__lte 1000: {list(Prestamo.objects.filter(monto__lte=Decimal('1000.00')).values('monto'))}")
            self.stdout.write(f"fecha__year 2024: {list(Prestamo.objects.filter(fecha_prestamo__year=2024).values('monto','fecha_prestamo'))}")
            self.stdout.write(f"monto__range (300,900): {list(Prestamo.objects.filter(monto__range=(Decimal('300.00'), Decimal('900.00'))).values('monto'))}")
            self.stdout.write(f"monto__exact 1500: {list(Prestamo.objects.filter(monto__exact=Decimal('1500.00')).values('monto'))}")
            self.stdout.write(f"empleado__nombre__icontains 'Juan': {list(Prestamo.objects.filter(empleado__nombre__icontains='Juan').values('monto'))}")
            self.stdout.write(f"exclude monto>1200: {list(Prestamo.objects.exclude(monto__gt=Decimal('1200.00')).values('monto'))}")
            self.stdout.write(f"tipo_prestamo Personal: {list(Prestamo.objects.filter(tipo_prestamo__descripcion='Personal').values('monto'))}")
            self.stdout.write(f"count: {Prestamo.objects.filter(id__in=prestamos).count()}")

            Prestamo.objects.filter(id=p4.id).delete(); Prestamo.objects.filter(id=p5.id).delete()
            self.stdout.write("Eliminación: 2 préstamos eliminados\n")

        # -----------------------
        # SOBRETIEMPO
        # -----------------------
        if Sobretiempo is None:
            self.stdout.write("Se omite SOBRETIEMPO: app no encontrada\n")
        else:
            self.stdout.write("=== SOBRETIEMPO ===")
            Sobretiempo.objects.filter(fecha_registro__year__gte=2024, empleado__cedula__in=['1001']).delete()
            tipo_50, _ = TipoSobretiempo.objects.get_or_create(codigo="H50", defaults={'descripcion': "Horas al 50%", 'factor': 1.5})
            emp_base = Empleado.objects.get(cedula="1001")
            s1 = Sobretiempo.objects.create(empleado=emp_base, fecha_registro=date(2024,11,1), tipo_sobretiempo=tipo_50, numero_horas=2, valor=Decimal('15.00'))
            s2 = Sobretiempo.objects.create(empleado=emp_base, fecha_registro=date(2024,11,5), tipo_sobretiempo=tipo_50, numero_horas=3, valor=Decimal('22.50'))
            s3 = Sobretiempo.objects.create(empleado=emp_base, fecha_registro=date(2024,10,20), tipo_sobretiempo=tipo_50, numero_horas=4, valor=Decimal('30.00'))
            s4 = Sobretiempo(empleado=emp_base, fecha_registro=date(2024,9,15), tipo_sobretiempo=tipo_50, numero_horas=1, valor=Decimal('7.50')); s4.save()
            s5 = Sobretiempo(empleado=emp_base, fecha_registro=date(2024,8,10), tipo_sobretiempo=tipo_50, numero_horas=5, valor=Decimal('37.50')); s5.save()
            self.stdout.write("Creación: 5 sobretiempos")

            Sobretiempo.objects.filter(id=s1.id).update(numero_horas=3)
            s2.numero_horas = 4; s2.save()
            Sobretiempo.objects.filter(id=s3.id).update(valor=F('valor') + Decimal('5.00'))
            s4.valor = Decimal('10.00'); s4.save()
            Sobretiempo.objects.filter(id=s5.id).update(valor=F('valor') + Decimal('2.00'))
            self.stdout.write("Actualización: OK")

            sobre_ids = [s1.id, s2.id, s3.id, s4.id, s5.id]
            self.stdout.write(f"all(): {Sobretiempo.objects.filter(id__in=sobre_ids)}")
            self.stdout.write(f"numero_horas__gte 3: {list(Sobretiempo.objects.filter(numero_horas__gte=3).values('numero_horas','valor'))}")
            self.stdout.write(f"fecha_registro__year 2024: {list(Sobretiempo.objects.filter(fecha_registro__year=2024).values('fecha_registro'))}")
            self.stdout.write(f"fecha_registro__month 11: {list(Sobretiempo.objects.filter(fecha_registro__month=11).values('fecha_registro'))}")
            self.stdout.write(f"valor__range (10,30): {list(Sobretiempo.objects.filter(valor__range=(Decimal('10.00'), Decimal('30.00'))).values('valor'))}")
            self.stdout.write(f"empleado__nombre__icontains 'Juan': {list(Sobretiempo.objects.filter(empleado__nombre__icontains='Juan').values('numero_horas'))}")
            self.stdout.write(f"tipo_sobretiempo H50: {list(Sobretiempo.objects.filter(tipo_sobretiempo__codigo='H50').values('numero_horas'))}")
            self.stdout.write(f"exclude numero_horas>4: {list(Sobretiempo.objects.exclude(numero_horas__gt=4).values('numero_horas'))}")
            self.stdout.write(f"fecha_registro__gte 2024-10-01: {list(Sobretiempo.objects.filter(fecha_registro__gte=date(2024,10,1)).values('fecha_registro'))}")
            self.stdout.write(f"count: {Sobretiempo.objects.filter(id__in=sobre_ids).count()}")

            Sobretiempo.objects.filter(id=s4.id).delete(); Sobretiempo.objects.filter(id=s5.id).delete()
            self.stdout.write("Eliminación: 2 sobretiempos eliminados\n")

        # -----------------------
        # NOMINA y NOMINADETALLE
        # -----------------------
        self.stdout.write("=== NOMINA ===")
        Nomina.objects.filter(aniomes__in=["202401","202402","202410","202411","202501"]).delete()
        n1 = Nomina.objects.create(aniomes="202401", usuario=usuario)
        n2 = Nomina.objects.create(aniomes="202402", usuario=usuario)
        n3 = Nomina.objects.create(aniomes="202410", usuario=usuario)
        n4 = Nomina(aniomes="202411", usuario=usuario); n4.save()
        n5 = Nomina(aniomes="202501", usuario=usuario); n5.save()
        self.stdout.write("Creación: 5 nóminas")

        Nomina.objects.filter(id=n1.id).update(aniomes="202401")
        n2.aniomes = "202402"; n2.save()
        Nomina.objects.filter(id__in=[n3.id, n4.id]).update(aniomes=F('aniomes'))
        n5.aniomes = "202501"; n5.save()
        self.stdout.write("Actualización: OK")

        nomina_ids = [n1.id, n2.id, n3.id, n4.id, n5.id]
        self.stdout.write(f"all(): {Nomina.objects.filter(id__in=nomina_ids)}")
        self.stdout.write(f"aniomes__startswith '2024': {list(Nomina.objects.filter(aniomes__startswith='2024').values('aniomes'))}")
        self.stdout.write(f"aniomes__contains '01': {list(Nomina.objects.filter(aniomes__contains='01').values('aniomes'))}")
        self.stdout.write(f"aniomes__endswith '10': {list(Nomina.objects.filter(aniomes__endswith='10').values('aniomes'))}")
        self.stdout.write(f"aniomes__gte '202410': {list(Nomina.objects.filter(aniomes__gte='202410').values('aniomes'))}")
        self.stdout.write(f"aniomes__lte '202402': {list(Nomina.objects.filter(aniomes__lte='202402').values('aniomes'))}")
        self.stdout.write(f"aniomes__range ('202401','202411'): {list(Nomina.objects.filter(aniomes__range=('202401','202411')).values('aniomes'))}")
        self.stdout.write(f"exclude aniomes__startswith '2025': {list(Nomina.objects.exclude(aniomes__startswith='2025').values('aniomes'))}")
        self.stdout.write(f"aniomes__exact '202410': {list(Nomina.objects.filter(aniomes__exact='202410').values('aniomes'))}")
        self.stdout.write(f"count: {Nomina.objects.filter(id__in=nomina_ids).count()}")

        Nomina.objects.filter(id=n1.id).delete(); Nomina.objects.filter(id=n5.id).delete()
        self.stdout.write("Eliminación: 2 nóminas eliminadas\n")

        # NominaDetalle
        self.stdout.write("=== NOMINA DETALLE ===")
        NominaDetalle.objects.filter(nomina__id__in=[n2.id, n3.id, n4.id]).delete()
        nomina_base = Nomina.objects.get(id=n2.id)
        emp1 = Empleado.objects.get(cedula="1001")
        nd1 = NominaDetalle.objects.create(nomina=nomina_base, empleado=emp1, sueldo=Decimal('1300.00'), neto=Decimal('1100.00'))
        nd2 = NominaDetalle.objects.create(nomina=nomina_base, empleado=emp1, sueldo=Decimal('1500.00'), neto=Decimal('1250.00'))
        nd3 = NominaDetalle.objects.create(nomina=nomina_base, empleado=emp1, sueldo=Decimal('2000.00'), neto=Decimal('1700.00'))
        nd4 = NominaDetalle(nomina=nomina_base, empleado=emp1, sueldo=Decimal('1800.00'), neto=Decimal('1520.00')); nd4.save()
        nd5 = NominaDetalle(nomina=nomina_base, empleado=emp1, sueldo=Decimal('2200.00'), neto=Decimal('1850.00')); nd5.save()
        self.stdout.write("Creación: 5 detalles")

        NominaDetalle.objects.filter(id=nd1.id).update(sueldo=F('sueldo') + Decimal('100.00'))
        nd2.neto = Decimal('1300.00'); nd2.save()
        NominaDetalle.objects.filter(id=nd3.id).update(sueldo=F('sueldo') + Decimal('50.00'))
        nd4.neto = Decimal('1600.00'); nd4.save()
        NominaDetalle.objects.filter(id=nd5.id).update(sueldo=Decimal('2300.00'))
        self.stdout.write("Actualización: OK")

        detalle_ids = [nd1.id, nd2.id, nd3.id, nd4.id, nd5.id]
        self.stdout.write(f"all(): {NominaDetalle.objects.filter(id__in=detalle_ids)}")
        self.stdout.write(f"sueldo__gte 1500: {list(NominaDetalle.objects.filter(sueldo__gte=Decimal('1500.00')).values('sueldo','neto'))}")
        self.stdout.write(f"neto__lt 1500: {list(NominaDetalle.objects.filter(neto__lt=Decimal('1500.00')).values('neto'))}")
        self.stdout.write(f"empleado__nombre__icontains 'Juan': {list(NominaDetalle.objects.filter(empleado__nombre__icontains='Juan').values('sueldo'))}")
        self.stdout.write(f"nomina__aniomes '202402': {list(NominaDetalle.objects.filter(nomina__aniomes='202402').values('sueldo','neto'))}")
        self.stdout.write(f"sueldo__range (1400,1900): {list(NominaDetalle.objects.filter(sueldo__range=(Decimal('1400.00'), Decimal('1900.00'))).values('sueldo'))}")
        self.stdout.write(f"neto__gte 1500: {list(NominaDetalle.objects.filter(neto__gte=Decimal('1500.00')).values('neto'))}")
        self.stdout.write(f"exclude neto>1800: {list(NominaDetalle.objects.exclude(neto__gt=Decimal('1800.00')).values('neto'))}")
        self.stdout.write(f"sueldo__range (1500,2000): {list(NominaDetalle.objects.filter(sueldo__range=(Decimal('1500.00'), Decimal('2000.00'))).values('sueldo'))}")
        self.stdout.write(f"count: {NominaDetalle.objects.filter(id__in=detalle_ids).count()}")

        NominaDetalle.objects.filter(id=nd1.id).delete(); NominaDetalle.objects.filter(id=nd5.id).delete()
        self.stdout.write("Eliminación: 2 detalles eliminados\n")

        # -----------------------
        # CONSULTAS AGREGADAS
        # -----------------------
        self.stdout.write("=== CONSULTAS AGREGADAS Y ANOTADAS ===")
        if Prestamo:
            self.stdout.write("1) Total de préstamos por empleado:")
            self.stdout.write(str(Prestamo.objects.select_related('empleado').values('empleado__nombre').annotate(total=Sum('monto')).order_by('-total')))
        else:
            self.stdout.write("1) Prestamo: N/A")

        self.stdout.write("2) Promedio de sueldos:")
        self.stdout.write(str(Empleado.objects.aggregate(promedio=Avg('sueldo'))))

        if Sobretiempo:
            self.stdout.write("3) Total horas extra por empleado:")
            self.stdout.write(str(Sobretiempo.objects.values('empleado__nombre').annotate(total_horas=Sum('numero_horas')).order_by('-total_horas')))
        else:
            self.stdout.write("3) Sobretiempo: N/A")

        self.stdout.write("4) Total a pagar por nómina:")
        self.stdout.write(str(NominaDetalle.objects.values('nomina__aniomes').annotate(total=Sum('neto')).order_by('nomina__aniomes')))

        # cargo puede no existir en todos los modelos -> try
        try:
            self.stdout.write("5) Número de empleados por cargo:")
            self.stdout.write(str(Empleado.objects.values('cargo').annotate(cantidad=Count('id')).order_by('cargo')))
        except Exception:
            self.stdout.write("5) Empleado.cargo: no disponible")

        self.stdout.write("6) Sueldo máximo y mínimo:")
        self.stdout.write(str(Empleado.objects.aggregate(max_sueldo=Max('sueldo'), min_sueldo=Min('sueldo'))))

        if Prestamo:
            self.stdout.write("7) Cantidad y suma de préstamos:")
            self.stdout.write(str(Prestamo.objects.aggregate(cantidad=Count('id'), total=Sum('monto'))))
        else:
            self.stdout.write("7) Prestamo: N/A")

        if Sobretiempo:
            self.stdout.write("8) Promedio valor sobretiempos:")
            self.stdout.write(str(Sobretiempo.objects.aggregate(promedio_valor=Avg('valor'))))
            self.stdout.write("9) Empleados con >3 horas extras:")
            self.stdout.write(str(Sobretiempo.objects.values('empleado__nombre').annotate(total_horas=Sum('numero_horas')).filter(total_horas__gt=3)))
        else:
            self.stdout.write("8/9) Sobretiempo: N/A")

        self.stdout.write("10) Top 5 empleados por neto:")
        self.stdout.write(str(NominaDetalle.objects.select_related('empleado').values('empleado__nombre').annotate(total_neto=Sum('neto')).order_by('-total_neto')[:5]))

        self.stdout.write("\n=== EJERCICIOS COMPLETADOS ===\n")
