class TitleContextMixin:
    """
    🔹 Mixin genérico para añadir títulos a las vistas.
    🔹 Se puede usar junto con cualquier vista basada en clases (CBV).
    """

    # Estas variables almacenarán los títulos que se enviarán al HTML.
    # Se pueden definir en cada vista que use este mixin.
    title1 = None
    title2 = None

    def get_context_data(self, **kwargs):
        #  Este método en Django sirve para crear o modificar el contexto
        # que se envía al archivo HTML (template).
        
        # Llamamos al método get_context_data() original de la clase padre (TemplateView)
        # para obtener el contexto base que Django ya genera.
        context = super().get_context_data(**kwargs)

        # Si la vista tiene definido title1, se agrega al contexto
        if self.title1:
            context["title1"] = self.title1

        if self.title2:
            context["title2"] = self.title2

        # Finalmente devolvemos el contexto completo,
        # listo para ser usado por el template (HTML)
        return context
