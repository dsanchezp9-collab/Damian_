from django.shortcuts import render, redirect
from django.views.generic import ListView, CreateView, UpdateView, DeleteView, TemplateView, DetailView
from django.contrib.auth.mixins import LoginRequiredMixin
from django.db.models import Q
from django.urls import reverse_lazy
from nomina.mixins import TitleContextMixin
from .forms import EmpleadoForm, NominaForm, NominaDetalleForm
from .models import NominaDetalle, Empleado, Nomina
from django import forms


def home(request):
    data = {
        "title1": "Autor | nose xd",
        "title2": "Gestión de Nóminas"
    }
    return render(request, 'home.html', data)


class HomeTemplateView(TitleContextMixin, TemplateView):
    # Esta clase muestra una página HTML estática (home.html)
    # Hereda de DOS clases:
    #                 TitleContextMixin → le permite enviar los títulos (title1, title2) al HTML
    #                       TemplateView → le dice a Django que esta vista renderiza una plantilla (template)

    #  Aquí indicamos el archivo HTML que se va a mostrar cuando se acceda a esta vista.
    template_name = 'home.html'

class EmpleadoListView(LoginRequiredMixin, TitleContextMixin, ListView):
    # 🔒 LoginRequiredMixin → impide el acceso si el usuario NO está autenticado (propio de Django).
    # 🏷️ TitleContextMixin → mixin creado por ti, agrega títulos al contexto (title1, title2).
    # 📋 ListView → clase de Django que muestra listas de objetos del modelo.

    model = Empleado                        
    template_name = 'empleado/list.html'    
    context_object_name = 'empleados'       
    paginate_by = 10                        
    title1 = "Autor | nose xd"              
    title2 = "Listado de Empleados"         

    def get_queryset(self):
        # ⚙️ Este método controla QUÉ datos se muestran en la lista.
        queryset = super().get_queryset()                      
        # 🧩 Llama al get_queryset original de ListView → devuelve todos los empleados del modelo.

        query = self.request.GET.get('q', '')  
        # 🔎 Toma el valor del parámetro 'q' desde la URL (ej. /empleados/?q=juan).
        # Si el usuario no busca nada, devuelve cadena vacía ''.

        if query:
            queryset = queryset.filter(
                Q(nombre__icontains=query) | Q(cedula__icontains=query)
                # 🧱 Q → clase de Django que permite combinar condiciones (OR / AND) en los filtros.
                # 🔤 __icontains=query → busca coincidencias parciales sin importar mayúsculas/minúsculas.
                # 📎 En conjunto: filtra empleados cuyo nombre O cédula contienen el texto de búsqueda.
            )
        return queryset  
        # ✅ Retorna el conjunto final de empleados (filtrados o no) para mostrarlos en el HTML.


class EmpleadoCreateView(LoginRequiredMixin, TitleContextMixin, CreateView):
    model = Empleado
    form_class = EmpleadoForm
    template_name = "empleado/form.html"
    success_url = reverse_lazy("nomina:empleado_list")
    title1 = "Empleados"
    title2 = "Crear Nuevo Empleado"

    def form_valid(self, form):
        form.instance.usuario = self.request.user  # ✅ Solución principal
        return super().form_valid(form)


class EmpleadoUpdateView(LoginRequiredMixin, TitleContextMixin, UpdateView):
    model = Empleado
    form_class = EmpleadoForm
    template_name = "empleado/form.html"
    success_url = reverse_lazy("nomina:empleado_list")
    title1 = "Empleado"
    title2 = "Editar Empleado"


class EmpleadoDeleteView(LoginRequiredMixin, TitleContextMixin, DeleteView):
    model = Empleado
    template_name = "empleado/delete.html"
    success_url = reverse_lazy("nomina:empleado_list")
    title1 = "Eliminar"
    title2 = "Eliminar Empleado"
class EmpleadoDetailView(LoginRequiredMixin, TitleContextMixin, DetailView):
    model = Empleado
    template_name = "empleado/detail.html"
    context_object_name = "empleado"  # nombre del objeto en el template
    title1 = "Empleado"
    title2 = "Datos del Empleado"
    success_url = reverse_lazy("nomina:empleado_list")
# nomina 
class NominaListView(LoginRequiredMixin, TitleContextMixin, ListView):
    model = Nomina
    template_name = 'nomina/list.html'
    context_object_name = 'nominas'
    paginate_by = 10
    title1 = "Autor | nose xd"
    title2 = "Listado de Nominas"

    def get_queryset(self):
        queryset = super().get_queryset()
        query = self.request.GET.get('q', '')
        if query:
            queryset = queryset.filter(Q(nombre__icontains=query) | Q(cedula__icontains=query))
        return queryset


class NominaCreateView(LoginRequiredMixin, TitleContextMixin, CreateView):
    model = Nomina
    form_class = NominaForm
    template_name = "nomina/form.html"
    success_url = reverse_lazy("nomina:nomina_list")
    title1 = "Nominas"
    title2 = "Crear Nueva Nomina"

    def form_valid(self, form):
        form.instance.usuario = self.request.user  # ✅ Solución principal
        return super().form_valid(form)


class NominaUpdateView(LoginRequiredMixin, TitleContextMixin, UpdateView):
    model = Nomina
    form_class = NominaForm
    template_name = "nomina/form.html"
    success_url = reverse_lazy("nomina:nomina_list")
    title1 = "Nomina"
    title2 = "Editar Nomina"


class NominaDeleteView(LoginRequiredMixin, TitleContextMixin, DeleteView):
    model = Nomina
    template_name = "nomina/delete.html"
    success_url = reverse_lazy("nomina:nomina_list")
    title1 = "Eliminar"
    title2 = "Eliminar Nomina"


#detalle de noimina 


class NominaDetalleListView(LoginRequiredMixin, TitleContextMixin, ListView):
    model = NominaDetalle
    template_name = 'nominadetalle/list.html'
    context_object_name = 'nominadetalle'
    paginate_by = 10
    title1 = "Autor | nose xd"
    title2 = "Listado de detalles de las nominas"

    def get_queryset(self):
        queryset = super().get_queryset()
        query = self.request.GET.get('q', '')
        if query:
            queryset = queryset.filter(Q(nombre__icontains=query) | Q(cedula__icontains=query))
        return queryset


class NominaDetalleCreateView(LoginRequiredMixin, TitleContextMixin, CreateView):
    model = NominaDetalle
    form_class = NominaDetalleForm
    template_name = "nominadetalle/form.html"
    success_url = reverse_lazy("nomina:nominadetalle_list")
    title1 = "Detalle de Nomina"
    title2 = "Crear nuevo detalle de Nomina"

    def form_valid(self, form):
        form.instance.usuario = self.request.user  # ✅ Solución principal
        return super().form_valid(form)
class NominaDetalleUpdateView(LoginRequiredMixin, TitleContextMixin, UpdateView):
    model = NominaDetalle
    form_class = NominaDetalleForm
    template_name = "nominadetalle/form.html"
    success_url = reverse_lazy("nomina:nominadetalle_list")
    title1 = "Detalle de Nomina"
    title2 = "Editar Detalle de Nomina"


class NominaDetalleDeleteView(LoginRequiredMixin, TitleContextMixin, DeleteView):
    model = NominaDetalle
    template_name = "nominadetalle/delete.html"
    success_url = reverse_lazy("nomina:nominadetalle_list")
    title1 = "Eliminar"
    title2 = "Eliminar Detalle de Nomina"

class NominaDetalleDetailView(LoginRequiredMixin, TitleContextMixin, DetailView):
    model = NominaDetalle
    template_name = "nominadetalle/detail.html"
    context_object_name = "nominadetalle"  # nombre del objeto en el template
    title1 = "Nomina"
    title2 = "Datos del Nomina"
    success_url = reverse_lazy("nomina:nominadetalle_list")