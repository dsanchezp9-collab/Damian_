from django import forms
from .models import Sobretiempo

class SobretiempoForm(forms.ModelForm):
    class Meta:
        model = Sobretiempo
        fields = ['image','empleado', 'tipo_sobretiempo', 'fecha_registro', 'numero_horas']
        widgets = {
            'fecha_registro': forms.DateInput(
                attrs={
                    'type': 'date',
                    'class': 'form-control'
                },
                format='%Y-%m-%d'  # 🔹 Asegura el formato correcto
            ),
        }

    def __init__(self, *args, **kwargs):
        super(SobretiempoForm, self).__init__(*args, **kwargs)
        if self.instance and self.instance.pk:  # 🔄 Está editando
            self.fields['fecha_registro'].initial = self.instance.fecha_registro.strftime('%Y-%m-%d')