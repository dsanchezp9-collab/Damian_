from django.apps import AppConfig


class SobretiempoConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'sobretiempo'
