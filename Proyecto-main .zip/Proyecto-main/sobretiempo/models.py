from django.db import models
from django.db import models
from nomina.models import Empleado
from decimal import Decimal

class TipoSobretiempo(models.Model):
    codigo = models.CharField(max_length=10)
    descripcion = models.CharField(max_length=100)
    factor = models.DecimalField(max_digits=4, decimal_places=2)

    def __str__(self):
        return self.descripcion

class Sobretiempo(models.Model):
    image = models.ImageField(verbose_name='Foto',upload_to='customers/',blank=True,null=True,default='customers/default.png')
    empleado = models.ForeignKey(Empleado, on_delete=models.CASCADE)
    fecha_registro = models.DateField()
    tipo_sobretiempo = models.ForeignKey(TipoSobretiempo, on_delete=models.CASCADE)
    numero_horas = models.DecimalField(max_digits=6, decimal_places=2)
    valor = models.DecimalField(max_digits=10, decimal_places=2, editable=False)

    def save(self, *args, **kwargs):
        horas_mensuales = Decimal('240')  # ← ÚNICO CAMBIO AQUÍ
        # Calculamos valor automáticamente según sueldo mensual del empleado
        self.valor = (self.empleado.sueldo / horas_mensuales) * self.numero_horas * self.tipo_sobretiempo.factor
        super().save(*args, **kwargs)

    def __str__(self):
        return f"Sobretiempo de {self.empleado.nombre} - {self.tipo_sobretiempo.descripcion}"