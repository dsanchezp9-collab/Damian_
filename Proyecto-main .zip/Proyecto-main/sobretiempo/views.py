from django.shortcuts import render, redirect
from django.views.generic import ListView, CreateView, UpdateView, DeleteView, TemplateView, DetailView
from django.contrib.auth.mixins import LoginRequiredMixin
from django.db.models import Q
from django.urls import reverse_lazy
from nomina.mixins import TitleContextMixin
from .forms import SobretiempoForm
from .models import  Sobretiempo
def home(request):
    data = {
        "title1": "Autor | nose xd",
        "title2": "Gestión de Nóminas"
    }
    return render(request, 'home.html', data)


class HomeTemplateView(TitleContextMixin, TemplateView):
    template_name = 'home.html'

class SobretiempoListView(LoginRequiredMixin, TitleContextMixin, ListView):
    model = Sobretiempo
    template_name = 'sobretiempo/list.html'
    context_object_name = 'sobretiempo'
    paginate_by = 10
    title1 = "Autor | nose xd"
    title2 = "Listado de sobretiempo"

    def get_queryset(self):
        queryset = super().get_queryset()
        query = self.request.GET.get('q', '')
        if query:
            queryset = queryset.filter(Q(empleado__nombre__icontains=query) | Q(empleado__cedula__icontains=query))

        return queryset


class SobretiempoCreateView(LoginRequiredMixin, TitleContextMixin, CreateView):
    model = Sobretiempo
    form_class = SobretiempoForm
    template_name = "sobretiempo/form.html"
    success_url = reverse_lazy("sobretiempo:sobretiempo_list")
    title1 = "sobretiempo"
    title2 = "Crear Nuevo sobretiempo"

    def form_valid(self, form):
        form.instance.usuario = self.request.user  # ✅ Solución principal
        return super().form_valid(form)


class SobretiempoUpdateView(LoginRequiredMixin, TitleContextMixin, UpdateView):
    model = Sobretiempo
    form_class = SobretiempoForm
    template_name = "sobretiempo/form.html"
    success_url = reverse_lazy("sobretiempo:sobretiempo_list")
    title1 = "sobretiempo"
    title2 = "Editar sobretiempo"


class SobretiempoDeleteView(LoginRequiredMixin, TitleContextMixin, DeleteView):
    model = Sobretiempo
    template_name = "sobretiempo/delete.html"
    success_url = reverse_lazy("sobretiempo:sobretiempo_list")
    title1 = "Eliminar"
    title2 = "Eliminar sobretiempo"

class SobretiempoDetailView(LoginRequiredMixin, TitleContextMixin, DetailView):
    model = Sobretiempo
    template_name = "sobretiempo/detail.html"
    context_object_name = "sobretiempo"  # nombre del objeto en el template
    title1 = "sobretiempo"
    title2 = "Datos del sobretiempo"
    success_url = reverse_lazy("sobretiempo:sobretiempo_list")
