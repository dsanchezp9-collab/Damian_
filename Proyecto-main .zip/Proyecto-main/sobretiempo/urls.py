from django.urls import path
from sobretiempo import views
app_name='sobretiempo'
urlpatterns = [
   path('', views.HomeTemplateView.as_view(),name='home'),
   path('sobretiempo_list/', views.SobretiempoListView.as_view(),name='sobretiempo_list'),
   path('sobretiempo_create/', views.SobretiempoCreateView.as_view(),name='sobretiempo_create'),
   path('sobretiempo_update/<int:pk>/', views.SobretiempoUpdateView.as_view(),name='sobretiempo_update'),
   path('sobretiempo_delete/<int:pk>/', views.SobretiempoDeleteView.as_view(),name='sobretiempo_delete'),
   path('sobretiempo_detail/<int:pk>/', views.SobretiempoDetailView.as_view(),name='sobretiempo_detail'),
]